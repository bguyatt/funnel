INSERT INTO user_temp_schema.jrl_daily_retention
    WITH #activation_dates AS (
        SELECT TRN.client_nkey,
               MIN(TRN.created_date)::date AS date_activated
        FROM _dwh_pii_plus_fraud.f_transaction TRN
        WHERE (TRN.cancelled_date IS NULL OR TRN.cancelled_date::date > TRN.created_date::date + 29)
        GROUP BY 1
    ), #last_12_weeks_transactions AS (
        SELECT TRN.client_nkey,
               GEO_S.country_name AS send_country,
               GEO_R.country_name AS receive_country,
               ROW_NUMBER() OVER (PARTITION BY TRN.client_nkey ORDER BY TRN.created_date DESC) AS trn_rank
        FROM _dwh_pii_plus_fraud.f_transaction TRN
        LEFT JOIN _dwh_pii_plus_fraud.d_geography GEO_S
            ON GEO_S.geography_skey = TRN.client_geography_skey
        LEFT JOIN _dwh_pii_plus_fraud.d_geography GEO_R
            ON GEO_R.geography_skey = TRN.recipient_geography_skey
        WHERE
            TRN.created_date::date BETWEEN DATE_ADD('DAY',-84, '{0}') AND DATE_ADD('DAY',-1, '{0}')
            AND (TRN.cancelled_date IS NULL OR TRN.cancelled_date::date > TRN.created_date::date + 29)
    ), #active_base AS (
        SELECT A.client_nkey,
               CASE WHEN A.send_country IN ('United States', 'United Kingdom', 'Australia', 'Canada', 'Germany', 'New Zealand', 'Sweden', 'France', 'Norway', 'Netherlands',
                                            'Belgium', 'Denmark', 'Switzerland', 'Ireland', 'Italy', 'Finland', 'Spain', 'Austria', 'Japan', 'South Africa')
                   THEN A.send_country ELSE 'ROW' END AS send_country,
               CASE WHEN A.receive_country IN ('Philippines', 'Ghana', 'Zimbabwe', 'Kenya', 'Nigeria', 'Cameroon', 'Uganda', 'India', 'Colombia', 'Somaliland',
                                               'Tanzania', 'South Africa', 'Rwanda', 'Nepal', 'Zambia', 'Pakistan', 'Mexico', 'Senegal', 'Congo Drc', 'Sierra Leone')
                   THEN A.receive_country ELSE 'ROW' END AS receive_country,
               CASE
                   WHEN B.date_activated BETWEEN DATE_ADD('DAY',-84, '{0}') AND DATE_ADD('DAY',-1, '{0}') THEN 1
                   ELSE 0
                   END AS new_client
        FROM #last_12_weeks_transactions A
        INNER JOIN #activation_dates B
            ON B.client_nkey = A.client_nkey
        WHERE A.trn_rank = 1
    )
    SELECT '{0}'::date as date,
           '4 week' AS window,
           ACT.send_country,
           ACT.receive_country,
           ACT.new_client,
           COUNT(DISTINCT ACT.client_nkey) AS base_clients,
           COUNT(DISTINCT TRN.client_nkey) AS retained_clients
    FROM #active_base ACT
    LEFT JOIN _dwh_pii_plus_fraud.f_transaction TRN
        ON TRN.client_nkey = ACT.client_nkey
        AND TRN.created_date::date BETWEEN '{0}' AND DATE_ADD('DAY',27, '{0}')
        AND (TRN.cancelled_date IS NULL OR TRN.cancelled_date::date > TRN.created_date::date + 29)
    GROUP BY 1,2,3,4,5 ;