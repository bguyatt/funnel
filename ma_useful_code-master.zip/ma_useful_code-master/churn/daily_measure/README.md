Code for updating the table `user_temp_schema.jrl_daily_retention` with daily 4w and 12w churn data. This is used by the churn dashboard: https://eu-west-1a.online.tableau.com/#/site/worldremittableaupoc/views/ChurnRates4w-DailyMeasure/DailyChurn

The code will drop the last 30 days of data from the table, and then run / insert new data one day at a time.
