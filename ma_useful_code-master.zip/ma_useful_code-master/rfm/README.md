### RFM Segmentation

This folder contains two scripts.
 * The Monthly script is used to create a table with clientss RFM segments at the end of each month since the start of 2019
 * The Weekly script updates a table with clients' Frequency segments at the end of each week for the last 4 weeks only. It also creates a "detlas" table which shows the clients who have changed frequency sine the previous week. This can be used to generate a file for the CRM team to use to update clients' frequencies.

NOTE: Weekly frequencies don't _exactly_ match Monthly frequencies due to edits being made to the code in order for it to run on a weekly basis. The code to generate this list is simply `select client_nkey, frequency from _prv_marketing.rfm_frequency_changes`
