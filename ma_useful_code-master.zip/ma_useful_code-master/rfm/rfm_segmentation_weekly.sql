/****************************** 12m back from last transaction date ******************************/
-- CREATE BASE TABLE FOR CLIENT BEHAVIOUR
drop table if exists #base_clients ;
create temporary table #base_clients as (
   with week_to_run as (
       select date_trunc('week',date_add('day',-30,current_date))::date + 6 as week_end
   ), min_max_trxns as (
       select WKR.week_end,
              TRN.client_nkey,
              min(TRN.created_date)::date as first_active,
              max(TRN.created_date)::date as last_active,
              count(distinct TRN.transaction_id) as lifetime_transactions
       from f_transaction TRN
       inner join week_to_run WKR
           on TRN.created_date::date <= WKR.week_end
       where (TRN.cancelled_date is null or TRN.cancelled_date::date > TRN.created_date::date + 29)
       group by 1,2
    )
    select MMT.week_end,
           MMT.client_nkey,
           MMT.first_active,
           MMT.last_active,
           MMT.lifetime_transactions,
           count(distinct date_trunc('week',TRN.created_date)) as weeks_active,
           count(distinct date_trunc('month',TRN.created_date)) as months_active
    from min_max_trxns MMT
    inner join f_transaction TRN
        on MMT.client_nkey = TRN.client_nkey
        and TRN.created_date::date between date_add('day', -363, MMT.last_active)::date and MMT.last_active
        and (TRN.cancelled_date is null or TRN.cancelled_date::date > TRN.created_date::date + 29)
    group by 1,2,3,4,5
) ;

-- INSERT LATEST WEEK INTO SEGMENTATION TABLE IF DOESN'T ALREADY EXIST
insert into _prv_marketing.rfm_user_segmentation_weekly (
    with rfm_update as (
        select week_end,
               client_nkey,
               first_active,
               last_active,
               lifetime_transactions,
               weeks_active,
               months_active,
               case
                   when first_active >= date_add('day',-83,week_end)::date then 'New'
                   when lifetime_transactions = 1 then 'One And Done'
                   when weeks_active >= 40 then 'Weekly'
                   when first_active > date_add('day', -363, week_end)::date and weeks_active >= 0.85 * (date_diff('week',first_active,week_end) + 1) then 'Weekly'
                   when weeks_active >= 22 and months_active >= date_diff('month',date_add('day', -363, week_end),week_end) - 2 then 'Fortnightly'
                   when first_active > date_add('day', -363, week_end)::date and weeks_active >= 0.45 * (date_diff('week',first_active,week_end) + 1) then 'Fortnightly'
                   when months_active >= date_diff('month',date_add('day', -363, week_end),week_end) - 1 then 'Monthly'
                   when first_active > date_add('day', -363, week_end)::date and months_active >= 0.20 * (date_diff('week',first_active,week_end) + 1) then 'Monthly'
                   else 'Infrequent'
                   end as frequency
        from #base_clients
    )
    select *
    from rfm_update
    where week_end not in (select distinct week_end from _prv_marketing.rfm_user_segmentation_weekly)
) ;

-- RANK WEEKS
drop table if exists #weeks_ranked ;
create temporary table #weeks_ranked as (
    select week_end,
           row_number() over (order by week_end desc) as week_rank
    from (select distinct week_end from _prv_marketing.rfm_user_segmentation_weekly) X
) ;

-- CREATE LIST OF FREQUENCY CHANGES DELTAS TABLE
drop table if exists #frequency_changes ;
create temporary table #frequency_changes as (
    with last_two_weeks as (
        select WKS.week_rank,
               WKS.week_end,
               RFM.client_nkey,
               RFM.frequency
        from _prv_marketing.rfm_user_segmentation_weekly RFM
        inner join #weeks_ranked WKS
            on RFM.week_end = WKS.week_end
            and WKS.week_rank <= 2
    )
    select LW.week_end,
           LW.client_nkey,
           LW.frequency
    from last_two_weeks LW
    left join last_two_weeks PW
        on LW.client_nkey = PW.client_nkey
    where LW.week_rank = 1
    and PW.week_rank = 2
    and (LW.frequency <> PW.frequency or PW.frequency is null)
) ;

-- INSERT LATEST WEEK INTO DELTAS TABLE IF DOESN'T ALREADY EXIST
insert into _prv_marketing.rfm_frequency_changes (
    select week_end,
           client_nkey,
           frequency
    from #frequency_changes
    where week_end not in (select distinct week_end from _prv_marketing.rfm_frequency_changes)
) ;

-- DELETE EXTRA ROWS FROM SEGMENTATION TABLE
delete from _prv_marketing.rfm_user_segmentation_weekly
    where week_end in (select week_end from #weeks_ranked where week_rank > 4 ) ;

-- DELETE EXTRA ROWS FROM DELTAS TABLE
delete from _prv_marketing.rfm_frequency_changes
    where week_end in (select week_end from #weeks_ranked where week_rank > 1 ) ;