/****************************** 12m back from last transaction date ******************************/
-- CREATE BASE TABLE FOR CLIENT 12M BEHAVIOUR
drop table if exists #base_clients ;
create table #base_clients as
    with months_to_run as (
        select distinct last_day(calendar_date) as month_end
        from d_calendar
        where calendar_date between (select max(month) from user_temp_schema.rfm_user_segmentation) and date_add('month', -1, sysdate)::date
    ), min_max_trxns as (
        select MTR.month_end,
               TRN.client_nkey,
               min(TRN.created_date)::date as first_active,
               max(TRN.created_date)::date as last_active,
               count(distinct TRN.transaction_id) as lifetime_transactions
        from months_to_run MTR
        inner join f_transaction TRN
            on TRN.created_date::date <= MTR.month_end
            and (TRN.cancelled_date is null or TRN.cancelled_date::date > TRN.created_date::date + 29)
        GROUP BY 1,2
    ), interim_step as (
        select MMT.month_end,
               MMT.client_nkey,
               MMT.first_active,
               MMT.last_active,
               MMT.lifetime_transactions,
               count(distinct date_trunc('month', TRN1.created_date)) as months,
               count(distinct date_trunc('week', TRN1.created_date)) as weeks,
               count(distinct TRN1.transaction_id) as transactions_last_active,
               sum(TRN1.send_amount_gbp) as send_amount_last_active,
               sum(TRN1.revenue_gbp) as revenue_last_active
        from min_max_trxns MMT
        left join f_transaction TRN1
            on TRN1.client_nkey = MMT.client_nkey
            and TRN1.created_date::date between date_add('month', -11, date_trunc('month',last_active))::date and last_day(last_active)::date
            and (TRN1.cancelled_date is null or TRN1.cancelled_date::date > TRN1.created_date::date + 29)
        group by 1,2,3,4,5
    )
    select ITS.month_end,
           ITS.client_nkey,
           ITS.first_active,
           ITS.last_active,
           ITS.lifetime_transactions,
           ITS.months,
           ITS.weeks,
           ITS.transactions_last_active,
           ITS.send_amount_last_active,
           ITS.revenue_last_active,
           count(DISTINCT TRN2.transaction_id) as transactions_mth,
           sum(TRN2.send_amount_gbp) as send_amount_mth,
           sum(TRN2.revenue_gbp) as revenue_mth
    from interim_step ITS
    left join f_transaction TRN2
        on TRN2.client_nkey = ITS.client_nkey
        and TRN2.created_date::date between date_add('month', -11, date_trunc('month',ITS.month_end))::date and ITS.month_end::date
        and (TRN2.cancelled_date is null or TRN2.cancelled_date::date > TRN2.created_date::date + 29)
    group by 1,2,3,4,5,6,7,8,9,10
 ;


-- DELETE ROWS FROM OUTPUT TABLE TO BE REPLACED
delete from user_temp_schema.rfm_user_segmentation
    where month in (select distinct date_trunc('month', month_end)::date AS month from #base_clients);

-- UPDATE OUTPUT TABLE
insert into user_temp_schema.rfm_user_segmentation
    select date_trunc('month', month_end)::date AS month,
           client_nkey,
           first_active,
           case
               when first_active >= date_trunc('month',month_end) then 'New'
               when first_active >= date_add('month', -2, date_trunc('month',month_end))::date then 'Recently New'
               when last_active >= date_trunc('month',month_end)::date then 'Last Month'
               when last_active >= date_add('month', -2, date_trunc('month',month_end))::date then 'Last 2-3 Months'
               when last_active >= date_add('month', -5, date_trunc('month',month_end))::date then 'Last 4-6 Months'
               when last_active >= date_add('month', -8, date_trunc('month',month_end))::date then 'Last 7-9 Months'
               when last_active >= date_add('month', -11, date_trunc('month',month_end))::date then 'Last 10-12 Months'
               else 'Over 12 months ago'
               end as recency,
           case
               when first_active >= date_add('month', -2, date_trunc('month',month_end))::date then 'New'
               when months = 0 then 'Inactive'
               when lifetime_transactions = 1 then 'One And Done'
               when weeks >= 40 then 'Weekly'
               when weeks = date_diff('weeks',first_active,last_day(last_active)::date) + 1 then 'Weekly'
               when weeks >= 22 AND months >= 9 then 'Fortnightly'
               when weeks = 0.5 * (date_diff('weeks',first_active,last_day(last_active)::date) + 1) then 'Fortnightly'
               when months >= 10 then 'Monthly'
               when months = date_diff('month',first_active,last_day(last_active)::date) + 1 then 'Monthly'
               else 'Infrequent'
               end as frequency,
           case
               when send_amount_last_active is null then 'Inactive'
               when send_amount_last_active <= 150 then '£0 - £149'
               when send_amount_last_active <= 500 then '£150 - £499'
               when send_amount_last_active <= 1500 then '£500 - £1499'
               when send_amount_last_active <= 5000 then '£1500 - £4999'
               else '£5000+'
               end as send_value,
           transactions_last_active as transactions_12m,
           send_amount_last_active as send_amount_12m,
           revenue_last_active as revenue_12m,
           transactions_mth as transactions_12m_cal,
           send_amount_mth as send_amount_12m_cal,
           revenue_mth as revenue_12m_cal
    from #base_clients ;


-- DROP BASE TEMP TABLE
drop table if exists #base_clients ;